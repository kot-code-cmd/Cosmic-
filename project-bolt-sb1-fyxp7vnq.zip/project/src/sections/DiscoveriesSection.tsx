import React from 'react';
import PlanetCard from '../components/PlanetCard';
import ParallaxEffect from '../components/ParallaxEffect';

const DiscoveriesSection: React.FC = () => {
  const discoveries = [
    {
      title: 'Nebula Nexus',
      description: 'A stunning cosmic cloud formation where new stars are born from interstellar dust and gas.',
      image: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      color: 'from-nebula-purple to-cosmic-blue'
    },
    {
      title: 'Quantum Quasar',
      description: 'An extremely luminous active galactic nucleus powered by a supermassive black hole.',
      image: 'https://images.unsplash.com/photo-1465101162946-4377e57745c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      color: 'from-aurora-blue to-aurora-purple'
    },
    {
      title: 'Stellar Synthesis',
      description: 'A rare phenomenon where multiple star systems merge to create a new celestial body.',
      image: 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      color: 'from-meteor-orange to-nebula-purple'
    },
    {
      title: 'Galactic Gateway',
      description: 'A theoretical wormhole connecting distant parts of the universe through spacetime.',
      image: 'https://images.unsplash.com/photo-1506703719100-a0b3a3a7f0c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      color: 'from-aurora-green to-aurora-blue'
    },
    {
      title: 'Cosmic Chronometer',
      description: 'An ancient celestial object that helps measure the age and expansion rate of the universe.',
      image: 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      color: 'from-cosmic-blue to-aurora-purple'
    },
    {
      title: 'Astral Anomaly',
      description: 'An unexplained cosmic phenomenon that challenges our current understanding of physics.',
      image: 'https://images.unsplash.com/photo-1454789548928-9efd52dc4031?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
      color: 'from-nebula-purple to-meteor-orange'
    }
  ];
  
  return (
    <section id="discoveries" className="relative py-20 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 glow">
            <span className="text-aurora-purple">COSMIC</span> DISCOVERIES
          </h2>
          <div className="w-24 h-1 bg-aurora-purple mx-auto mb-6"></div>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Explore our latest findings from the depths of space, each discovery expanding our understanding of the universe.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {discoveries.map((discovery, index) => (
            <ParallaxEffect key={index} speed={0.01 + (index * 0.005)}>
              <PlanetCard
                title={discovery.title}
                description={discovery.description}
                image={discovery.image}
                link="#"
                color={discovery.color}
              />
            </ParallaxEffect>
          ))}
        </div>
      </div>
      
      {/* Orbital decoration */}
      <div className="absolute -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] border border-cosmic-blue/10 rounded-full"></div>
      <div className="absolute -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[100%] h-[100%] border border-nebula-purple/10 rounded-full"></div>
      <div className="absolute -z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[80%] h-[80%] border border-aurora-blue/10 rounded-full"></div>
    </section>
  );
};

export default DiscoveriesSection;