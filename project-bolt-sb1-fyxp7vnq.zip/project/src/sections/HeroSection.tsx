import React, { useEffect, useRef } from 'react';
import ParallaxEffect from '../components/ParallaxEffect';
import GlowingButton from '../components/GlowingButton';
import { ChevronDown } from 'lucide-react';

const HeroSection: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      
      const { clientX, clientY } = e;
      const { width, height } = heroRef.current.getBoundingClientRect();
      
      const x = clientX / width;
      const y = clientY / height;
      
      heroRef.current.style.setProperty('--mouse-x', x.toString());
      heroRef.current.style.setProperty('--mouse-y', y.toString());
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);
  
  return (
    <section 
      id="home" 
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background: `radial-gradient(
          circle at calc(var(--mouse-x, 0.5) * 100%) calc(var(--mouse-y, 0.5) * 100%),
          rgba(74, 26, 122, 0.5),
          rgba(10, 10, 26, 0.9) 50%
        )`
      }}
    >
      {/* Dynamic stars in background handled by StarField component in App.tsx */}
      
      <div className="container mx-auto px-4 z-10 text-center">
        <ParallaxEffect speed={0.03}>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-orbitron font-bold mb-6 glow">
            <span className="text-aurora-blue">EXPLORE</span> THE{' '}
            <span className="text-aurora-purple">COSMOS</span>
          </h1>
        </ParallaxEffect>
        
        <ParallaxEffect speed={0.05}>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-10 text-gray-300">
            Journey through the infinite wonders of space with our cutting-edge cosmic exploration platform
          </p>
        </ParallaxEffect>
        
        <ParallaxEffect speed={0.02}>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <GlowingButton 
              glowColor="aurora-green"
              className="w-48"
            >
              Begin Journey
            </GlowingButton>
            
            <GlowingButton 
              glowColor="aurora-purple"
              className="w-48"
            >
              Discover More
            </GlowingButton>
          </div>
        </ParallaxEffect>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#mission" className="text-gray-400 hover:text-white transition-colors">
          <ChevronDown className="w-8 h-8" />
        </a>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-nebula-purple/20 blur-3xl"></div>
      <div className="absolute bottom-1/3 right-1/4 w-40 h-40 rounded-full bg-cosmic-blue/20 blur-3xl"></div>
    </section>
  );
};

export default HeroSection;