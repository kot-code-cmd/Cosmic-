import React, { useState } from 'react';
import TerminalInput from '../components/TerminalInput';
import GlowingButton from '../components/GlowingButton';
import { Send, MessageSquare, Mail, MapPin } from 'lucide-react';

const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send the form data to a server
    console.log({ name, email, message });
    setSubmitted(true);
    
    // Reset form after submission
    setTimeout(() => {
      setName('');
      setEmail('');
      setMessage('');
      setSubmitted(false);
    }, 3000);
  };
  
  const contactInfo = [
    {
      icon: <MessageSquare className="w-5 h-5 text-aurora-blue" />,
      title: 'Chat',
      detail: 'Live Support 24/7'
    },
    {
      icon: <Mail className="w-5 h-5 text-aurora-green" />,
      title: 'Email',
      detail: 'contact@cosmosexp.com'
    },
    {
      icon: <MapPin className="w-5 h-5 text-aurora-purple" />,
      title: 'Location',
      detail: 'Orbital Station Alpha'
    }
  ];
  
  return (
    <section id="contact" className="relative py-20 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 glow">
            <span className="text-aurora-green">COMMUNICATION</span> TERMINAL
          </h2>
          <div className="w-24 h-1 bg-aurora-green mx-auto mb-6"></div>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Connect with our mission control to share your thoughts, questions, or join our cosmic exploration team.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="mission-control rounded-lg p-6">
            <h3 className="text-xl font-orbitron font-semibold mb-6 text-star-white">Transmit Message</h3>
            
            {submitted ? (
              <div className="text-center py-10">
                <div className="text-aurora-green text-xl mb-4">Message Transmitted Successfully!</div>
                <p className="text-gray-400">Thank you for contacting us. We will respond shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Name</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-aurora-green opacity-70">{'>'}</span>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="w-full bg-deep-space border border-aurora-blue/30 rounded-md py-3 pl-8 pr-3 
                                text-aurora-green font-mono placeholder-aurora-green/30
                                focus:outline-none focus:border-aurora-blue focus:ring-1 focus:ring-aurora-blue"
                      placeholder="Enter your name"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Email</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-aurora-green opacity-70">{'>'}</span>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full bg-deep-space border border-aurora-blue/30 rounded-md py-3 pl-8 pr-3 
                                text-aurora-green font-mono placeholder-aurora-green/30
                                focus:outline-none focus:border-aurora-blue focus:ring-1 focus:ring-aurora-blue"
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Message</label>
                  <div className="relative">
                    <span className="absolute left-3 top-3 text-aurora-green opacity-70">{'>'}</span>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      required
                      rows={5}
                      className="w-full bg-deep-space border border-aurora-blue/30 rounded-md py-3 pl-8 pr-3 
                                text-aurora-green font-mono placeholder-aurora-green/30
                                focus:outline-none focus:border-aurora-blue focus:ring-1 focus:ring-aurora-blue"
                      placeholder="Type your message here..."
                    ></textarea>
                  </div>
                </div>
                
                <div className="text-right">
                  <GlowingButton 
                    glowColor="aurora-green"
                    className="inline-flex items-center"
                    onClick={() => {}}
                  >
                    Transmit <Send className="ml-2 w-4 h-4" />
                  </GlowingButton>
                </div>
              </form>
            )}
          </div>
          
          {/* Contact Info */}
          <div className="space-y-8">
            <div className="mission-control rounded-lg p-6">
              <h3 className="text-xl font-orbitron font-semibold mb-6 text-star-white">Communication Channels</h3>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-cosmic-blue/30 flex items-center justify-center mr-4">
                      {info.icon}
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-star-white">{info.title}</h4>
                      <p className="text-gray-400">{info.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mission-control rounded-lg p-6">
              <h3 className="text-xl font-orbitron font-semibold mb-6 text-star-white">Mission Status</h3>
              
              <div className="terminal-text space-y-3">
                <div>
                  <div>{'>'} system.uptime</div>
                  <div className="text-aurora-blue">1,342 DAYS</div>
                </div>
                <div>
                  <div>{'>'} communication.status</div>
                  <div className="text-aurora-green">ONLINE</div>
                </div>
                <div>
                  <div>{'>'} response.time</div>
                  <div className="text-meteor-orange">24-48 HOURS</div>
                </div>
                <div>
                  <div>{'>'} team.location</div>
                  <div className="text-aurora-purple">GLOBAL NETWORK</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 w-full h-40 bg-gradient-to-t from-deep-space to-transparent"></div>
      <div className="absolute -z-10 top-1/3 right-10 w-64 h-64 rounded-full bg-nebula-purple/5 blur-3xl"></div>
    </section>
  );
};

export default ContactSection;