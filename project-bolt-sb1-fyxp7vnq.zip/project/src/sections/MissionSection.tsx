import React from 'react';
import ParallaxEffect from '../components/ParallaxEffect';
import OrbitalElement from '../components/OrbitalElement';
import { Compass, Rocket, Zap, Globe } from 'lucide-react';

const MissionSection: React.FC = () => {
  const missions = [
    {
      icon: <Compass className="w-6 h-6 text-aurora-blue" />,
      title: 'Exploration',
      description: 'Venturing into the unknown regions of space to discover new celestial phenomena'
    },
    {
      icon: <Rocket className="w-6 h-6 text-aurora-green" />,
      title: 'Innovation',
      description: 'Developing cutting-edge technologies to advance our understanding of the cosmos'
    },
    {
      icon: <Zap className="w-6 h-6 text-meteor-orange" />,
      title: 'Discovery',
      description: 'Uncovering the mysteries of the universe through scientific observation and analysis'
    },
    {
      icon: <Globe className="w-6 h-6 text-aurora-purple" />,
      title: 'Collaboration',
      description: 'Working together across disciplines and borders to expand human knowledge'
    }
  ];
  
  return (
    <section id="mission" className="relative py-20 overflow-hidden">
      <div className="mission-control rounded-lg max-w-6xl mx-auto my-10 p-6 md:p-10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-orbitron font-bold mb-4 glow">
              <span className="text-aurora-green">MISSION</span> CONTROL
            </h2>
            <div className="w-24 h-1 bg-aurora-green mx-auto mb-6"></div>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Our mission is to explore the vast frontiers of space, pushing the boundaries of human knowledge and inspiring the next generation of cosmic explorers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {missions.map((mission, index) => (
              <ParallaxEffect key={index} speed={0.02 + (index * 0.01)}>
                <div className="bg-deep-space border border-cosmic-blue/30 rounded-lg p-6 transition-all duration-300 hover:border-aurora-blue hover:shadow-glow">
                  <div className="flex items-center mb-4">
                    <OrbitalElement 
                      size="w-12 h-12" 
                      color="bg-cosmic-blue/30" 
                      orbitSpeed={10 + (index * 5)}
                    >
                      {mission.icon}
                    </OrbitalElement>
                    <h3 className="ml-4 text-xl font-orbitron font-semibold text-star-white">{mission.title}</h3>
                  </div>
                  <p className="text-gray-400">{mission.description}</p>
                  
                  {/* Terminal-like interface elements */}
                  <div className="mt-4 pt-4 border-t border-cosmic-blue/30">
                    <div className="terminal-text text-xs">
                      <div>{'>'} mission.status</div>
                      <div className="text-aurora-blue">ACTIVE</div>
                      <div>{'>'} mission.progress</div>
                      <div className="text-aurora-green">
                        <div className="w-full bg-cosmic-blue/30 rounded-full h-1.5 mt-1">
                          <div 
                            className="bg-aurora-green h-1.5 rounded-full pulse" 
                            style={{ width: `${65 + (index * 5)}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </ParallaxEffect>
            ))}
          </div>
          
          <div className="mt-16 text-center">
            <div className="terminal-text inline-block text-left bg-deep-space border border-cosmic-blue/30 rounded p-4 max-w-2xl mx-auto">
              <div>{'>'} system.status</div>
              <div className="text-aurora-green">ALL SYSTEMS OPERATIONAL</div>
              <div>{'>'} mission.objective</div>
              <div className="text-aurora-blue">EXPAND HUMAN KNOWLEDGE OF THE COSMOS</div>
              <div>{'>'} mission.eta</div>
              <div className="text-meteor-orange">ONGOING</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-1/3 left-10 w-64 h-64 rounded-full bg-nebula-purple/5 blur-3xl"></div>
      <div className="absolute bottom-1/4 right-10 w-80 h-80 rounded-full bg-cosmic-blue/5 blur-3xl"></div>
    </section>
  );
};

export default MissionSection;