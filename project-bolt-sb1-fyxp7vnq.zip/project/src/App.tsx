import React, { useEffect, useState } from 'react';
import StarField from './components/StarField';
import Constellation from './components/Constellation';
import Navbar from './components/Navbar';
import HeroSection from './sections/HeroSection';
import MissionSection from './sections/MissionSection';
import DiscoveriesSection from './sections/DiscoveriesSection';
import ContactSection from './sections/ContactSection';
import Footer from './components/Footer';
import LoadingSpinner from './components/LoadingSpinner';

function App() {
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, []);
  
  if (loading) {
    return (
      <div className="min-h-screen bg-deep-space flex flex-col items-center justify-center">
        <StarField starCount={100} />
        <LoadingSpinner />
        <p className="mt-6 text-aurora-blue font-orbitron text-lg">Initializing Cosmic Interface...</p>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-deep-space">
      {/* Background effects */}
      <StarField />
      <Constellation />
      
      {/* Main content */}
      <Navbar />
      <main>
        <HeroSection />
        <MissionSection />
        <DiscoveriesSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;