import React from 'react';
import { ExternalLink } from 'lucide-react';

interface PlanetCardProps {
  title: string;
  description: string;
  image: string;
  link?: string;
  color?: string;
}

const PlanetCard: React.FC<PlanetCardProps> = ({
  title,
  description,
  image,
  link,
  color = 'from-cosmic-blue to-nebula-purple'
}) => {
  return (
    <div className="planet nebula-effect w-full max-w-sm mx-auto overflow-hidden rounded-lg transition-all duration-500">
      <div className={`bg-gradient-to-br ${color} p-1`}>
        <div className="bg-deep-space p-5 h-full">
          <div className="relative w-full h-48 mb-4 overflow-hidden rounded">
            <img 
              src={image} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
            />
          </div>
          
          <h3 className="text-xl font-orbitron font-bold mb-2 text-star-white glow">{title}</h3>
          <p className="text-gray-300 mb-4">{description}</p>
          
          {link && (
            <a 
              href={link} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center text-aurora-blue hover:text-aurora-green transition-colors duration-300"
            >
              Explore <ExternalLink className="ml-1 w-4 h-4" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default PlanetCard;