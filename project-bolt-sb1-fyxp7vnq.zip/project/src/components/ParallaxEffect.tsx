import React, { useEffect, useRef, ReactNode } from 'react';

interface ParallaxEffectProps {
  children: ReactNode;
  speed?: number;
  className?: string;
}

const ParallaxEffect: React.FC<ParallaxEffectProps> = ({ 
  children, 
  speed = 0.05,
  className = ''
}) => {
  const elementRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;
    
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      
      const deltaX = (clientX - centerX) * speed;
      const deltaY = (clientY - centerY) * speed;
      
      element.style.transform = `translate(${deltaX}px, ${deltaY}px)`;
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [speed]);
  
  return (
    <div ref={elementRef} className={`parallax-layer ${className}`}>
      {children}
    </div>
  );
};

export default ParallaxEffect;