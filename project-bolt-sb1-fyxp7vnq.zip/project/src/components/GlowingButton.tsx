import React, { ReactNode } from 'react';

interface GlowingButtonProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  glowColor?: string;
}

const GlowingButton: React.FC<GlowingButtonProps> = ({
  children,
  onClick,
  className = '',
  glowColor = 'aurora-blue'
}) => {
  return (
    <button
      onClick={onClick}
      className={`
        relative overflow-hidden px-6 py-3 
        bg-transparent border border-${glowColor} rounded-md
        text-${glowColor} font-orbitron font-medium
        transition-all duration-300 ease-in-out
        hover:bg-${glowColor}/10 hover:shadow-glow
        focus:outline-none focus:ring-2 focus:ring-${glowColor}/50
        ${className}
      `}
    >
      <span className="relative z-10">{children}</span>
      <span className={`
        absolute inset-0 bg-gradient-to-r from-${glowColor}/0 via-${glowColor}/30 to-${glowColor}/0
        opacity-0 hover:opacity-100 transition-opacity duration-300
      `}></span>
    </button>
  );
};

export default GlowingButton;