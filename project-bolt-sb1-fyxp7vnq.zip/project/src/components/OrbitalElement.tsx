import React, { ReactNode } from 'react';

interface OrbitalElementProps {
  children: ReactNode;
  size?: string;
  color?: string;
  className?: string;
  orbitSpeed?: number;
}

const OrbitalElement: React.FC<OrbitalElementProps> = ({
  children,
  size = 'w-16 h-16',
  color = 'bg-nebula-purple',
  className = '',
  orbitSpeed = 20
}) => {
  const orbitStyle = {
    animationDuration: `${orbitSpeed}s`
  };
  
  return (
    <div 
      className={`orbital-element ${size} ${color} flex items-center justify-center ${className} orbit`}
      style={orbitStyle}
    >
      {children}
    </div>
  );
};

export default OrbitalElement;