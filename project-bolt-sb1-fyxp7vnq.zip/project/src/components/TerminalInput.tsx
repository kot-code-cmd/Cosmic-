import React, { useState, ChangeEvent, FormEvent } from 'react';
import { Send } from 'lucide-react';

interface TerminalInputProps {
  onSubmit: (value: string) => void;
  placeholder?: string;
  buttonText?: string;
}

const TerminalInput: React.FC<TerminalInputProps> = ({
  onSubmit,
  placeholder = 'Enter your message...',
  buttonText = 'Send'
}) => {
  const [value, setValue] = useState('');
  
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setValue(e.target.value);
  };
  
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (value.trim()) {
      onSubmit(value);
      setValue('');
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="flex w-full">
      <div className="relative flex-1">
        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-aurora-green opacity-70">{'>'}</span>
        <input
          type="text"
          value={value}
          onChange={handleChange}
          placeholder={placeholder}
          className="w-full bg-deep-space border border-aurora-blue/30 rounded-l-md py-3 pl-8 pr-3 
                    text-aurora-green font-mono placeholder-aurora-green/30
                    focus:outline-none focus:border-aurora-blue focus:ring-1 focus:ring-aurora-blue"
        />
      </div>
      <button
        type="submit"
        className="bg-aurora-blue hover:bg-aurora-purple transition-colors duration-300 
                  text-star-white font-orbitron px-4 rounded-r-md flex items-center"
      >
        <span className="hidden sm:inline mr-2">{buttonText}</span>
        <Send className="w-4 h-4" />
      </button>
    </form>
  );
};

export default TerminalInput;