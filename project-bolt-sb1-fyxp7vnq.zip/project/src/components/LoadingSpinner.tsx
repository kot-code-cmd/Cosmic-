import React from 'react';

interface LoadingSpinnerProps {
  size?: string;
  color?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  size = 'w-12 h-12',
  color = 'aurora-blue'
}) => {
  return (
    <div className={`loading-orbit ${size} mx-auto`}>
      <div className={`w-full h-full rounded-full border-2 border-${color}/20 relative`}>
        <div 
          className={`absolute w-3 h-3 bg-${color} rounded-full`}
          style={{
            top: '0',
            left: '50%',
            transform: 'translateX(-50%)',
            animation: 'orbit 1.5s linear infinite'
          }}
        ></div>
      </div>
    </div>
  );
};

export default LoadingSpinner;