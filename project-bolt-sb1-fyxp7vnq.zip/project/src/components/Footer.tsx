import React from 'react';
import { Rocket, Github, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="relative bg-deep-space border-t border-cosmic-blue/30 py-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div className="md:col-span-1">
            <div className="flex items-center mb-4">
              <Rocket className="h-6 w-6 text-aurora-blue mr-2" />
              <span className="text-lg font-orbitron font-bold text-star-white">COSMOS</span>
            </div>
            <p className="text-gray-400 text-sm">
              Exploring the infinite wonders of space through cutting-edge technology and scientific discovery.
            </p>
          </div>
          
          {/* Quick links */}
          <div>
            <h4 className="text-star-white font-orbitron font-medium mb-4">Navigation</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-aurora-blue transition-colors">Home</a></li>
              <li><a href="#mission" className="text-gray-400 hover:text-aurora-blue transition-colors">Mission</a></li>
              <li><a href="#discoveries" className="text-gray-400 hover:text-aurora-blue transition-colors">Discoveries</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-aurora-blue transition-colors">Contact</a></li>
            </ul>
          </div>
          
          {/* Resources */}
          <div>
            <h4 className="text-star-white font-orbitron font-medium mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-aurora-blue transition-colors">Research</a></li>
              <li><a href="#" className="text-gray-400 hover:text-aurora-blue transition-colors">Publications</a></li>
              <li><a href="#" className="text-gray-400 hover:text-aurora-blue transition-colors">Media</a></li>
              <li><a href="#" className="text-gray-400 hover:text-aurora-blue transition-colors">Careers</a></li>
            </ul>
          </div>
          
          {/* Social links */}
          <div>
            <h4 className="text-star-white font-orbitron font-medium mb-4">Connect</h4>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-aurora-blue transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-aurora-purple transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-aurora-green transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
            <p className="mt-4 text-gray-400 text-sm">
              Subscribe to our cosmic newsletter for the latest updates.
            </p>
            <div className="mt-2 flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-cosmic-blue/20 border border-cosmic-blue/30 rounded-l-md px-3 py-2 text-sm text-gray-300 focus:outline-none focus:border-aurora-blue"
              />
              <button className="bg-aurora-blue hover:bg-aurora-purple transition-colors px-3 py-2 rounded-r-md text-white text-sm">
                Join
              </button>
            </div>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-cosmic-blue/30 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Cosmos Exploration. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-gray-400 text-sm">Cookie Policy</a>
          </div>
        </div>
      </div>
      
      {/* Decorative stars */}
      <div className="absolute top-10 left-10 w-1 h-1 bg-star-white rounded-full opacity-70 twinkle" style={{ '--delay': '0' } as React.CSSProperties}></div>
      <div className="absolute top-20 left-20 w-1 h-1 bg-star-white rounded-full opacity-70 twinkle" style={{ '--delay': '0.5' } as React.CSSProperties}></div>
      <div className="absolute top-15 left-40 w-1 h-1 bg-star-white rounded-full opacity-70 twinkle" style={{ '--delay': '1' } as React.CSSProperties}></div>
      <div className="absolute top-30 right-20 w-1 h-1 bg-star-white rounded-full opacity-70 twinkle" style={{ '--delay': '1.5' } as React.CSSProperties}></div>
      <div className="absolute top-10 right-40 w-1 h-1 bg-star-white rounded-full opacity-70 twinkle" style={{ '--delay': '2' } as React.CSSProperties}></div>
    </footer>
  );
};

export default Footer;