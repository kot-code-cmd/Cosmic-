/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'deep-space': '#0a0a1a',
        'cosmic-blue': '#1a1a4a',
        'nebula-purple': '#4a1a7a',
        'star-white': '#ffffff',
        'aurora-green': '#1aff8c',
        'aurora-blue': '#1a8cff',
        'aurora-purple': '#8c1aff',
        'meteor-orange': '#ff8c1a',
      },
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
        rajdhani: ['Rajdhani', 'sans-serif'],
      },
      animation: {
        'slow-pulse': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'orbit': 'orbit 20s linear infinite',
        'twinkle': 'twinkle 3s infinite',
      },
      keyframes: {
        orbit: {
          '0%': { transform: 'rotate(0deg) translateX(10px) rotate(0deg)' },
          '100%': { transform: 'rotate(360deg) translateX(10px) rotate(-360deg)' },
        },
        twinkle: {
          '0%, 100%': { opacity: 0.2 },
          '50%': { opacity: 1 },
        },
      },
      backgroundImage: {
        'space-gradient': 'linear-gradient(135deg, var(--cosmic-blue), var(--nebula-purple))',
        'aurora-gradient': 'linear-gradient(135deg, var(--aurora-blue), var(--aurora-purple), var(--aurora-green))',
      },
      boxShadow: {
        'glow': '0 0 15px rgba(26, 140, 255, 0.7)',
        'planet': '0 0 30px rgba(138, 43, 226, 0.5)',
      },
    },
  },
  plugins: [],
};